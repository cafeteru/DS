package parte2;

public interface MovieType {	
	public double getPrice(Rental rental);
	public int getPoints(Rental rental);
}
