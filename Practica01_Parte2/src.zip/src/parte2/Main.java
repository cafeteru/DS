package parte2;

public class Main {

	public static void main(String[] args) {

		Customer raul = new Customer("Ra�l");

		Movie hotFuzz = new Movie("Hot Fuzz", new Movie_new_release());
		MovieType toyStory = new Movie_childrens("Toy Story");
		MovieType zombiesParty = new Movie_regular("Zombies Party");
		

		raul.addRental(new Rental(hotFuzz, 2));
		raul.addRental(new Rental(toyStory, 6));
		raul.addRental(new Rental(zombiesParty, 8));

		System.out.println(raul.status());

	}
}
