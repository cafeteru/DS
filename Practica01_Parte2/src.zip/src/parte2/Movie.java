package parte2;

public class Movie {
	private String titulo;
	private MovieType tipo;
	
	public Movie(String titulo, MovieType tipo) {
		this.titulo = titulo;
		this.tipo = tipo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public MovieType getTipo() {
		return tipo;
	}

	public void setTipo(MovieType tipo) {
		this.tipo = tipo;
	}
	
	
}
